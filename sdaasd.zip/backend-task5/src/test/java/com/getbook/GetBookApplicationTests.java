package com.getbook;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GetBookApplicationTests {

	@Test
	void contextLoads() {
	}

}
